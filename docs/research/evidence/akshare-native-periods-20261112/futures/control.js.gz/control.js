/**
	@description ����300 control
	@author xingben1
	@version 0.1
*/
var control = (function($){
	var IE_6 = $.browser.msie&&($.browser.version=="6.0");
	var control = {
			render:function(opt){
				var container = opt.container;
				$(container).hide();
				var data =  opt.data;
				var tmpl = opt.tmpl;
				$.template(tmpl.name, tmpl.markup );
				var html = $.tmpl(tmpl.name,data,tmpl.opt);
				$(container).empty().append(html).show();
				if($.isFunction(opt.callback)){
					opt.callback($(container));		
				}
			},
			init:function(){
				view.init();
				modular.init();
			}
		};
	//����ͼ�󶨸��²���;
	$(control).bind("onRender",function(e,data){
		control.render(data);
	});	
	//���������ɾ���¼�;
	$(control).bind("onDeleteLatestStock",function(e,code,type){
		modular.latset_hot_futures.delete_latest(code,type);
	});
	//��ѡ����ָ�¼�;
	$(control).bind("onSelect",function(e,data){
		modular.select.change(data);
	});
	//�󶨲�ѯ�¼�;
	$(control).bind("onQuery",function(e,data){
		modular.select.query(data);
	});
	//�󶨲�ѯ��ʷ�¼�;
	$(control).bind("onQueryHistory",function(e,data){
		modular.select.query_history(data);
	});
	//
	$(control).bind("onCalcExchange",function(e,data){
		modular.calc.calc(data);
	});
	return control;
})(jQuery)